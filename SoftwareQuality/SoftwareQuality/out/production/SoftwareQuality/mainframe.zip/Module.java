package mainframe;

import java.util.ArrayList;
import java.util.List;

public class Module{
    public String name;
    public List<Function> functions = new ArrayList<>();
    public List<Violation> violations = new ArrayList<>();

    public QualityScore qualityScore = new QualityScore();

    public void add(Violation violation) {
        String functionName = violation.function;
        if(violation.function.equals("File Scope")) {
            violations.add(violation);
            return;
        }
        Function function = functions.stream().filter(e->e.name.equals(functionName)).findAny().orElse(new Function(functionName));
        if(function.violations.isEmpty()) {
            functions.add(function);
        }
        function.add(violation);
    }
    public Module(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }
}
