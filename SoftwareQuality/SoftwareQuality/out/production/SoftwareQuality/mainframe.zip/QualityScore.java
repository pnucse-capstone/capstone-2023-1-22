package mainframe;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QualityScore {
    public enum severity {
        LOW, MEDIUM, HIGH
    }

    static final int TOTAL_GUIDELINE_COUNT = 610;
    static final int TOTAL_MAINTAINABILITY_GUIDELINE = 36;
    static final int TOTAL_PERFORMANCE_GUIDELINE = 20;
    static final int TOTAL_RELIABILITY_GUIDELINE = 372;
    static final int TOTAL_SECURITY_GUIDELINE = 373;
    static final int TOTAL_PORTABILITY_GUIDELINE = 65;

    double totalQualityScore = 0;
    double maintainabilityCount = 0;
    double performanceCount = 0;
    double reliabilityCount = 0;
    double securityCount = 0;
    double portabilityCount = 0;

    private Map<String, Integer> guidelineCount =  new HashMap<>();

    public void violationCount(List<Violation> violations) {
        violations.forEach(e-> {
            if(guidelineCount.containsKey(e.identifier)) {
                int count = guidelineCount.remove(e.identifier)+1;
                guidelineCount.put(e.identifier,count);
            } else {
                guidelineCount.put(e.identifier,1);
            }
        });
    }

    public void scoreCount(List<CodingGuideline> codingGuidelines) {
        guidelineCount.forEach((identifier, count)-> {
            CodingGuideline guideline = codingGuidelines.stream().filter(e->identifier.equals(e.identifier)).findAny().orElse(null);
            assert guideline != null;
            if(Boolean.TRUE.equals(guideline.maintainability)) {
                maintainabilityCount += (1+0.05*(count-1))*count;
            }
            if(Boolean.TRUE.equals(guideline.performance)) {
                performanceCount += (1+0.05*(count-1))*count;
            }
            if(Boolean.TRUE.equals(guideline.reliability)) {
                reliabilityCount += (1+0.05*(count-1))*count;
            }
            if(Boolean.TRUE.equals(guideline.security)) {
                securityCount += (1+0.05*(count-1))*count;
            }
            if(Boolean.TRUE.equals(guideline.portability)) {
                portabilityCount += (1+0.05*(count-1))*count;
            }
        });
    }

    public void functionScoreCalculate() {
        totalQualityScore = (Math.max((1-(maintainabilityCount/ TOTAL_MAINTAINABILITY_GUIDELINE)),0) +
                (Math.max(1-(performanceCount/ TOTAL_PERFORMANCE_GUIDELINE),0)) +
                (Math.max(1-(reliabilityCount/ TOTAL_RELIABILITY_GUIDELINE),0)) +
                (Math.max(1-(securityCount/ TOTAL_SECURITY_GUIDELINE),0)) +
                (Math.max(1-(portabilityCount/ TOTAL_PORTABILITY_GUIDELINE),0)))*100/5;
    }

    public void moduleScoreCalculate(List<Function> functions, boolean emptyViolation) {
        double functionscore = 0;
        for(Function function:functions) {
            function.qualityScore.functionScoreCalculate();
            functionscore+=function.qualityScore.totalQualityScore;
        }
        if(emptyViolation) {
            totalQualityScore = functionscore/functions.size();
        } else {
            functionScoreCalculate();
            if(!functions.isEmpty()) {
                totalQualityScore = 0.5 * (totalQualityScore + functionscore / functions.size());
            }
        }
    }

    public void systemScoreCalculate(List<Module> modules) {
        double moduleScore = 0;
        for(Module module:modules) {
            module.qualityScore.moduleScoreCalculate(module.functions, module.violations.isEmpty());
            moduleScore+=module.qualityScore.totalQualityScore;
        }
        totalQualityScore = moduleScore/modules.size();
    }
}
