package mainframe;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class MainFrame extends JFrame {

    private JButton openButton;
    private JTextArea textArea;

    private JTextArea scoreArea;
    private static final String GUIDELINE_PATH = "Coding_Guideline.txt";
    System system = new System("test");
    ArrayList<CodingGuideline> codingGuideLines;

    public MainFrame() {
        setTitle("Main Frame");
        setSize(1000, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        DefaultMutableTreeNode root = new DefaultMutableTreeNode(system);

        codingGuideLines = new ArrayList<>();
        try {
            guidelineReader(GUIDELINE_PATH);
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(MainFrame.this, "Error reading guideline File.");
        }

        openButton = new JButton("Open Polyspace Report File");
        openButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int returnValue = fileChooser.showOpenDialog(MainFrame.this);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                try {
                    String selectedFilePath = fileChooser.getSelectedFile().getAbsolutePath();
                    String fileContent = reportReader(selectedFilePath);
                    textArea.setText(fileContent);
                    for (Module module : system.modules) {
                        DefaultMutableTreeNode moduleNode = new DefaultMutableTreeNode(module);
                        for (Function function : module.functions) {
                            moduleNode.add(new DefaultMutableTreeNode(function));
                        }
                        root.add(moduleNode);
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(MainFrame.this, "Error reading the file.");
                }
            }
        });

        scoreArea = new JTextArea();
        scoreArea.setEditable(false);
        textArea = new JTextArea();
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        JTree tree = new JTree(root);
        tree.addTreeSelectionListener(e -> {
            DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
            if (selectedNode != null) {
                Object selectedObject = selectedNode.getUserObject();
                if (selectedObject instanceof System) {
                    scoreArea.setText(String.valueOf(system.qualityScore.totalQualityScore));
                    textArea.setText("");
                } else if (selectedObject instanceof Module module) {
                    scoreArea.setText(String.valueOf(module.qualityScore.totalQualityScore));
                    StringBuilder moduleViolation = new StringBuilder();
                    module.violations.forEach(moduleViolation::append);
                    textArea.setText(moduleViolation.toString());
                } else if (selectedObject instanceof Function function) {
                    scoreArea.setText(String.valueOf(function.qualityScore.totalQualityScore));
                    StringBuilder functionViolation = new StringBuilder();
                    function.violations.forEach(functionViolation::append);
                    textArea.setText(functionViolation.toString());
                }
            }
        });

        JScrollPane scrollPane2 = new JScrollPane(tree);
        scoreArea.setSize(200,100);

        JPanel panel = new JPanel();
        JPanel mainText = new JPanel();
        mainText.setLayout(new BorderLayout());
        panel.setLayout(new BorderLayout());
        panel.add(openButton, BorderLayout.NORTH);
        panel.add(mainText, BorderLayout.CENTER);
        mainText.add(scoreArea,BorderLayout.NORTH);
        mainText.add(scrollPane,BorderLayout.CENTER);
        panel.add(scrollPane2,BorderLayout.WEST);

        add(panel);
    }

    private String reportReader(String filePath) throws IOException {
        StringBuilder content = new StringBuilder();
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        reader.readLine();
        int i = 0;
        int j = 0;
        while ((line = reader.readLine()) != null) {
            String[] splitLine = line.split("\t");
            if(splitLine[1].equals("Defect")) {
                continue;
            }
            i++;
            String[] idAndDescription = splitLine[5].split(" ",2);
            Violation violation;
            if(idAndDescription[0].equals("Dir")) {
                String[] idnAndDescription = idAndDescription[1].split(" ",2);
                idAndDescription[0]+= " " +idnAndDescription[0];
                violation = new Violation(splitLine[0], splitLine[1], idAndDescription[0],idnAndDescription[1],splitLine[7],splitLine[8]);
            }
            else {
                if(splitLine[1].equals("MISRA C:2012")) {idAndDescription[0] = "Rule " + idAndDescription[0];}
                if(splitLine[1].equals("CWE")) {idAndDescription[0] = "CWE-" + idAndDescription[0];}
                violation = new Violation(splitLine[0], splitLine[1], idAndDescription[0],idAndDescription[1],splitLine[7],splitLine[8]);
            }
            if(codingGuideLines.stream().noneMatch(e->e.identifier.equals(violation.identifier))) {
                continue;
            }
            j++;

            system.add(violation);
            content.append(violation);
        }
        system.scoreCalculate(codingGuideLines);
        content.append("total " + i +" violation / filtered violation " + j + "\n");
        reader.close();
        return content.toString();
    }

    private void guidelineReader(String filePath) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] splitLine = line.split("\t",-1);
            CodingGuideline guideline = new CodingGuideline(splitLine[0],splitLine[1]);
            if(splitLine[2].equals("O")) {guideline.maintainability = true;}
            if(splitLine[3].equals("O")) {guideline.performance = true;}
            if(splitLine[4].equals("O")) {guideline.reliability = true;}
            if(splitLine[5].equals("O")) {guideline.security = true;}
            if(splitLine[6].equals("O")) {guideline.portability = true;}
            codingGuideLines.add(guideline);
        }
        reader.close();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame mainFrame = new MainFrame();
            mainFrame.setVisible(true);
        });
    }
}