package mainframe;

import java.util.ArrayList;
import java.util.List;

public class Function{
    public String name;
    public List<Violation> violations = new ArrayList<>();

    public void add(Violation violation) {
        violations.add(violation);
    }

    public Function(String name) {
        this.name = name;
    }

    public QualityScore qualityScore = new QualityScore();

    @Override
    public String toString() {
        return name;
    }
}
