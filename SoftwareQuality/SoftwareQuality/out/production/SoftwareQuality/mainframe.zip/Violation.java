package mainframe;

public class Violation {
    public String id;
    public String codingStandard;
    public String identifier;
    public String description;
    public String function;
    public String module;

    public Violation(String id, String codingStandard, String identifier, String description, String function, String module) {
        this.id = id;
        this.codingStandard = codingStandard;
        this.identifier = identifier;
        this.description = description;
        this.function = function;
        this.module = module;
    }

    @Override
    public String toString() {
        return "Violation{" +
                "id=" + id +
                ", codingStandard='" + codingStandard + '\'' +
                ", identifier='" + identifier + '\'' +
                ", description='" + description + '\'' +
                ", function='" + function + '\'' +
                ", file='" + module + '\'' +
                "'}"+"\n";
    }
}
