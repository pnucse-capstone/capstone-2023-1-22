package mainframe;

import java.util.ArrayList;
import java.util.List;

public class System{
    public String name;
    public List<Module> modules = new ArrayList<>();

    public System(String name) {
        this.name = name;
    }

    public QualityScore qualityScore = new QualityScore();

    public void add(Violation violation) {
        String moduleName = violation.module;
        Module module = modules.stream().filter(e->e.name.equals(moduleName)).findAny().orElse(new Module(moduleName));
        if(module.violations.isEmpty()&&module.functions.isEmpty()) {
            modules.add(module);
        }
        module.add(violation);
    }

    public void scoreCalculate(List<CodingGuideline> codingGuideLines) {
        modules.forEach(e->{
            if(!e.violations.isEmpty()) {
                e.qualityScore.violationCount(e.violations);
                e.qualityScore.scoreCount(codingGuideLines);
            }
            e.functions.forEach(ex->{
                ex.qualityScore.violationCount(ex.violations);
                ex.qualityScore.scoreCount(codingGuideLines);
            });
        });
        qualityScore.systemScoreCalculate(modules);
    }

    @Override
    public String toString() {
        return name;
    }
}
